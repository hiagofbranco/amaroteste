<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define( 'DB_NAME', 'wp-amaro' );

/** Usuário do banco de dados MySQL */
define( 'DB_USER', 'root' );

/** Senha do banco de dados MySQL */
define( 'DB_PASSWORD', '' );

/** Nome do host do MySQL */
define( 'DB_HOST', 'localhost' );

/** Charset do banco de dados a ser usado na criação das tabelas. */
define( 'DB_CHARSET', 'utf8mb4' );

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '}jA_R6)z$GHk!QHne~Pb]@6OTX?=+zl^jX(Z=Q31y6z+ y>XG`(s5?NU~_5/keX+' );
define( 'SECURE_AUTH_KEY',  '~ZM7Up!gdg9<A+Xnb7JK@kUkso>+/Dtb5AnlT/G8hn/5IFMnF6P_`bF{#j];PSp/' );
define( 'LOGGED_IN_KEY',    '~Yiv=U!|Us1h65PoCOBSk%U%La{#_ym]ER-0FI_Sy(ZSQwC6d]r)?*}D.!RsdE2d' );
define( 'NONCE_KEY',        ';m|ka+W[:H=!St@An*@wn/:)zOD;azgMl-<Mbc0>UjzY,sw)]K7$uON7>/`kn).M' );
define( 'AUTH_SALT',        'KxW>u2(Y-f-vdCot4O*.@f6hQOMgSpgbBc-y@U{_IbwU2EZUoLnQP2x}}W.SzJoH' );
define( 'SECURE_AUTH_SALT', '@{9d+BC*]*+R-ppX;,to)5c$FN>XSk&,S.fw09O;!g1>2+.#U$~K txKS74r7c6r' );
define( 'LOGGED_IN_SALT',   'O$GJE@OIkW(,<W?u[WxQfa%A=9L8vJM|Zu^75vDzcruI@kYa}gDzJA )3AVP`F6Q' );
define( 'NONCE_SALT',       '-lt4bZlH_uN:vBO8KLd-i5@Ks8<gR(hmr;74Lk+S{7`:.Xw7P.Evrxu_3J|-b<|#' );

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Configura as variáveis e arquivos do WordPress. */
require_once ABSPATH . 'wp-settings.php';
